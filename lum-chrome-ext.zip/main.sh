sudo mv lumExt /usr/bin;
sudo mkdir /lumExt;
sudo mv index.php /lumExt;
lum mv lumExtFolder ~/;
echo "Пропишите в автозагрузку 'lumExt', а так же установите расширение из папки пользователя в хром";