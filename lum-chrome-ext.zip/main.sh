sudo chmod +x lumExt;
sudo mv lumExt /usr/bin;
sudo mkdir /lumExt;
sudo mv index.php /lumExt;
lum mv lumExtFolder /home;
echo "Пропишите в автозагрузку 'lumExt', а так же установите расширение из '/home/lumExtFolder' в хром";