sudo chmod +x lumExt;
sudo mv lumExt /usr/bin;
sudo mkdir /lumExt;
sudo mv index.php /lumExt;
sudo mv lumExtFolder /home;
sudo mv removeScript /lumRm/lumExt;
echo "Пропишите в автозагрузку 'lumExt', а так же установите расширение из '/home/lumExtFolder' в хром";