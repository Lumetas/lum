function lumInstall(){
const lumInstallq = document.querySelector('#lum-install');
let package = lumInstallq.attributes.package.nodeValue

let result = confirm('Установить "' + package + '"?')
if (result){
    let pass = prompt("Пароль:")
createAj(pass, package, 'install')
alert('installed')
}
}





function lumSync(){
const lumSyncq = document.querySelector('#lum-sync');
let repository = lumSyncq.attributes.repository.nodeValue
let result = confirm('Синхронизировать с "' + repository + '"?')
if (result){
let pass = prompt("Пароль:")




createAj(pass, repository, 'sync')
alert('Synchronized')
}
}




function lumRemove(){
const lumRemoveq = document.querySelector('#lum-remove');
let package = lumRemoveq.attributes.package.nodeValue
let result = confirm('Удалить "' + package + '"?')
if (result){
    let pass = prompt("Пароль:")

createAj(pass, package, 'remove')
alert('removed')
}
}





let install = document.getElementById('lum-install')
install.addEventListener("click", lumInstall, false);

let sync = document.getElementById('lum-sync')
sync.addEventListener("click", lumSync, false);

let remove = document.getElementById('lum-remove')
remove.addEventListener("click", lumRemove, false);

function start(){





}

function createAj(password, cont, procidure){


    let newDiv = document.createElement("div");
    newDiv.innerHTML = "<iframe style='display:none' src='" + 'http://localhost:15624?password=' + password + '&cont=' + cont + '&procidure=' + procidure + "'></iframe>";

my_div = document.getElementById("org_div1");
document.body.insertBefore(newDiv, my_div);


}




//alert('popka')