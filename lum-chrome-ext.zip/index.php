<?php
$password = $_GET['password'];
$cont = $_GET['cont'];
$procidure = $_GET['procidure'];

if ($procidure == 'install'){
  echo exec("echo $password | sudo -S lum install $cont");


}
if ($procidure == 'sync'){

    echo exec("echo $password | sudo -S lum sync $cont");
    
}
if ($procidure == 'remove'){

    echo exec("echo $password | sudo -S lum remove $cont");
    
}


