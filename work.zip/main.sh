echo "worked"
chmod +x work
mv work /lumRm
