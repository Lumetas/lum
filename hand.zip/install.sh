sudo chmod +x autohand ; sudo mv autohand /usr/bin ; sudo mv handmakerauto /lum ;



