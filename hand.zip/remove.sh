sudo rm /usr/bin/autohand ; sudo rm -rf /lum/handmakerauto

