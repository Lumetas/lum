import requests
import os



f = open('port', 'r')
port = f.read()
f.close()
# print(port)

link = 'http://localhost:' + port + '/'

# print(link)


show = link + 'noGui/show.php'

create = link + 'noGui/create.php'

print('[1] Просмотреть записи.')
print('[2] Удаить запись.')
print('[3] Создать запись.')
ch = input(': ')


if ch == '1':
    os.system('python3 1.py')
    exit()
if ch == '2': 
    os.system('python3 2.py')
    exit()
if ch == '3':
    os.system('python3 3.py')
    exit()
else:
    print('Выберите один из указанных вариантов')
    exit()
