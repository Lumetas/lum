import requests 
import os


f = open('port', 'r')
port = f.read()
f.close()
# print(port)


def char_code(c):
    return c.decode('utf-8')

link = 'http://localhost:' + port + '/'

# print(link)


show = link + 'noGui/show.php'

create = link + 'noGui/create.php'



r = requests.get(show)
cont = char_code(r.content)
print(cont)



name = input(': ')


r = requests.get(show + '?name=' + name)
cont = char_code(r.content)
print(cont)

