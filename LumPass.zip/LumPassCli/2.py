import requests
import os



f = open('port', 'r')
port = f.read()
f.close()
# print(port)

link = 'http://localhost:' + port + '/'

# print(link)
def char_code(c):
    return c.decode('utf-8')


show = link + 'noGui/show.php'

create = link + 'noGui/create.php'

delete = link + 'noGui/delete.php'



r = requests.get(show)
cont = char_code(r.content)
print(cont)



name = input('Удалить: ')


r = requests.get(delete + '?name=' + name)
cont = char_code(r.content)
print('Удалено.')


