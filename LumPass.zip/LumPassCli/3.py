import requests
import os

def char_code(c):
    return c.decode('utf-8')


f = open('port', 'r')
port = f.read()
f.close()
# print(port)

link = 'http://localhost:' + port + '/'

# print(link)


show = link + 'noGui/show.php'

create = link + 'noGui/create.php'


name = input('Введите название записи: ')
login = input('Введите логин: ')
password = input('Введите пароль: ')


url = create + '?name=' + name + '&login=' + login + '&pass=' + password
print(url)

r = requests.get(url)
cont = char_code(r.content)
print(cont)

