
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src='script.js'></script>
  	<link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<a href='index.php'>Домой</a><br><br>
<div style='width:400px; height:400px' >

   <form method='get'>

<input placeholder='Просмотреть' type='text' name='name'>

</form> 
</body>
</html>


<?php 
$fName = $_GET['name'];
	
	$repka = $fName;
include('repka.php');
$fName = $repka;


$dir = '/lumPass';
 
$files = array();
foreach(glob($dir . '/'.$fName.'*.*') as $file) {
	$files[] = basename($file);	
} 
	
if ($fName != ''){



$src = '/lumPass/'.$files[0];



$fd = fopen($src, 'r') or die("не удалось открыть файл");
while(!feof($fd))
{
$str = htmlentities(fgets($fd));
$str = str_replace('
', '<br>', $str);
echo $str;
}
fclose($fd);



}

if ($fName == ''){
foreach ($files as &$value) {
$fil = str_replace('.txt', '', $value);
echo  "<a href='?name=$fil'>$fil</a>".'
<br><br>
';
}}


?>


</div>
