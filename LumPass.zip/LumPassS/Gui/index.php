<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src='script.js'></script>
  	<link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<a href='create.php'>Создать</a><br><br>
<a href='show.php'>Просмотреть</a><br><br>
<a href='delete.php'>Удалить</a>     <br><br>
</body>
</html>
