<div style='width:400px; height:400px' >

<?php
if ($_GET['name'] != '' && $_GET['login'] != '' && $_GET['pass'] != ''){
	$e = '
';

	$cont = 'login: '.$_GET['login'].$e.'password: '.$_GET['pass'];




$fd = fopen('/lumPass/'.$_GET['name'].".txt", 'w') or die("не удалось создать файл");
$str = "$cont";
fwrite($fd, $str);
fclose($fd);

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src='script.js'></script>
  	<link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<a href='index.php'>Домой</a><br><br>
<form method='get'>
<input type='text' name='name' placeholder='Имя записи'><br><br>
<input type='text' name='login' placeholder='Логин'><br><br>
<input type='text' name='pass' placeholder='Пароль'><br><br>
<input type='submit'>



</div>
</form>    
</body>
</html>
