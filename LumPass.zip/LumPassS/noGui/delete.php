<?php
$fName = $_GET['name'];

        $repka = $fName;
include('repka.php');
$fName = $repka;


$dir = '/lumPass';

$files = array();
foreach(glob($dir . '/'.$fName.'*.*') as $file) {
        $files[] = basename($file);
}

if ($fName != ''){



$src = '/lumPass/'.$files[0];

unlink($src);


}

if ($fName == ''){
foreach ($files as &$value) {
$fil = str_replace('.txt', '', $value);
echo  "$fil".'

';
}}


?>
~     
