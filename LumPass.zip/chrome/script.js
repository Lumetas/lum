setTimeout(start, 1000);
function start(){

if (localStorage.getItem('port') !== null){
let port = localStorage.getItem('port');
document.getElementById('frame').src = 'http://localhost:' + port + '/Gui/index.php';
}
else {
console.log('dfs');
let port = prompt('port');
if (port !== ''){
if (port !== null){
localStorage.setItem('port', port)
}}}
}
